#!/bin/sh
# Reproduces every result, table and figure of the paper.
# Total CPU time on a 2-core machine: roughly 10-12 hours.
set -e

# 1) Adequacy simulation, ENS and labels  -> sim.pkl
python data.py

# 2) Verify the quantum simulator against PennyLane (optional)
python test_qsim.py || echo "PennyLane not installed - skipping simulator check"

# 3) Base-configuration study: comparison, ablation, lambda, percentile, horizon -> results/
python run.py main
python run.py ablation
python run.py reup
python run.py lam
python run.py pct
python run.py horizon

# 4) Validation-only hyperparameter search (no test predictions) -> results_v2/search_*
python tune.py search hq
python tune.py search twin
python tune.py search rnn
python tune.py search gbm

# 5) Final 3-seed evaluation on the test year -> results_v2/final_*
python final_all.py hqtcan2 twin2 lstm transformer vqc qsann hqtcn lgbm logreg persistence

# 6) Tables, bootstrap tests and figures -> figs/
python final_analysis.py
python -c "import final_analysis as F; F.fig_convergence_v2()"
python -c "import analyze as A; A.fig_timeseries(); A.fig_sensitivity()"
python analyze.py
python make_tables.py
python fig_framework.py
