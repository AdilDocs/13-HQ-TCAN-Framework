"""Check the in-house simulator against PennyLane (expectation values and gradients)."""
import math
import numpy as np
from autograd import grad
import pennylane as qml
from pennylane import numpy as pnp
import qsim

rng = np.random.default_rng(1)
phi = rng.uniform(0, math.pi, (5, 4))
th = rng.uniform(0, 2 * math.pi, 12)
dev = qml.device("default.qubit", wires=4)


@qml.qnode(dev)
def ref(x, t):
    for k in range(4):
        qml.Hadamard(k); qml.RZ(2 * x[k], k)
    for k in range(3):
        qml.CNOT([k, k + 1]); qml.RZ(2 * (math.pi - x[k]) * (math.pi - x[k + 1]), k + 1); qml.CNOT([k, k + 1])
    i = 0
    for r in range(3):
        for k in range(4):
            qml.RY(t[i], k); i += 1
        if r < 2:
            for k in range(3):
                qml.CNOT([k, k + 1])
    return [qml.expval(qml.PauliZ(k)) for k in range(4)]


f = lambda t: qsim.expval_z(qsim.real_amplitudes(qsim.zz_feature_map(phi), t, 2), range(4))
ours = f(th)
theirs = np.array([np.array(ref(phi[b], th)) for b in range(5)])
print("max |difference| in <Z_k>:", np.abs(ours - theirs).max())

g_ours = grad(lambda t: f(t)[:, 0].sum())(th)
g_ref = qml.grad(lambda t: sum(ref(phi[b], t)[0] for b in range(5)))(pnp.array(th, requires_grad=True))
print("max |difference| in gradients:", np.abs(g_ours - np.asarray(g_ref)).max())

# 6-qubit check (ZZ map + RealAmplitudes, reps=1)
dev6 = qml.device("default.qubit", wires=6)
phi6 = rng.uniform(0, math.pi, (3, 6)); th6 = rng.uniform(0, 2 * math.pi, 12)


@qml.qnode(dev6)
def ref6(x, t):
    for k in range(6):
        qml.Hadamard(k); qml.RZ(2 * x[k], k)
    for k in range(5):
        qml.CNOT([k, k + 1]); qml.RZ(2 * (math.pi - x[k]) * (math.pi - x[k + 1]), k + 1); qml.CNOT([k, k + 1])
    for k in range(6):
        qml.RY(t[k], k)
    for k in range(5):
        qml.CNOT([k, k + 1])
    for k in range(6):
        qml.RY(t[6 + k], k)
    return [qml.expval(qml.PauliZ(k)) for k in range(6)]


o6 = qsim.expval_z(qsim.real_amplitudes(qsim.zz_feature_map(phi6), th6, 1), range(6))
r6 = np.array([np.array(ref6(phi6[b], th6)) for b in range(3)])
print("6-qubit max |difference|:", np.abs(o6 - r6).max())
s6 = qsim.zero_state(3, 6)
for k in range(6):
    s6 = qsim.ry(s6, k, phi6[:, k])
print("6-qubit encoding diff:", np.abs(s6 - qsim.angle_encoding(phi6)).max())
