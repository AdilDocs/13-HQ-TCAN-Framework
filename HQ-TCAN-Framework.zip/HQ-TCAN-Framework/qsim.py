"""Exact, batched state-vector simulator for small qubit registers (autograd/NumPy, differentiable).

The register size n is inferred from the state width (2**n amplitudes); HQ-TCAN uses n = 4 or 6.
Circuits are simulated exactly and differentiated with automatic differentiation, which for
noiseless expectation values gives the same gradients as the analytic parameter-shift rule.
Correctness is verified against PennyLane in test_qsim.py.
"""
import math
import warnings
from functools import lru_cache
warnings.filterwarnings("ignore", message="Casting complex values")
import numpy as onp
import autograd.numpy as np

N = 4            # default register size


def _n(state):
    return int(round(math.log2(state.shape[1])))


def zero_state(batch, n=N):
    s = onp.zeros((batch, 2 ** n), complex)
    s[:, 0] = 1.0
    return s


def _apply_1q(state, wire, M):
    """state (B, 2^n); M (2,2) or (B,2,2). Wire 0 is the most significant qubit."""
    B, n = state.shape[0], _n(state)
    s = np.moveaxis(np.reshape(state, (B,) + (2,) * n), wire + 1, -1)
    if M.ndim == 2:
        s = s @ M.T
    else:
        shp = s.shape
        s = np.reshape(np.einsum("bxj,bij->bxi", np.reshape(s, (B, -1, 2)), M), shp)
    return np.reshape(np.moveaxis(s, -1, wire + 1), (B, 2 ** n))


def _vec(theta, B):
    return theta * onp.ones(B)


def ry(state, wire, theta):
    th = _vec(theta, state.shape[0])
    c, s = np.cos(th / 2), np.sin(th / 2)
    M = np.stack([np.stack([c, -s], -1), np.stack([s, c], -1)], -2)
    return _apply_1q(state, wire, M)


def rz(state, wire, theta):
    th = _vec(theta, state.shape[0])
    em, ep = np.exp(-0.5j * th), np.exp(0.5j * th)
    z = 0.0 * em
    M = np.stack([np.stack([em, z], -1), np.stack([z, ep], -1)], -2)
    return _apply_1q(state, wire, M)


_H = onp.array([[1, 1], [1, -1]], complex) / math.sqrt(2)


def hadamard(state, wire):
    return _apply_1q(state, wire, _H)


@lru_cache(maxsize=None)
def _cnot_perm(n, c, t):
    perm = []
    for i in range(2 ** n):
        bits = [(i >> (n - 1 - k)) & 1 for k in range(n)]
        if bits[c]:
            bits[t] ^= 1
        perm.append(sum(b << (n - 1 - k) for k, b in enumerate(bits)))
    return onp.array(perm)


def cnot(state, c, t):
    return state[:, _cnot_perm(_n(state), c, t)]


@lru_cache(maxsize=None)
def _zsign(n):
    return onp.array([[1.0 - 2 * ((i >> (n - 1 - k)) & 1) for i in range(2 ** n)] for k in range(n)])


def expval_z(state, wires=(0,)):
    p = np.real(state) ** 2 + np.imag(state) ** 2
    return np.dot(p, _zsign(_n(state))[list(wires)].T)            # (B, len(wires))


# ---------------- circuit blocks ----------------

def angle_encoding(phi):
    """R_y angle encoding of phi (B, n) in [0, pi]: the product state
    (x)_k [cos(phi_k/2), sin(phi_k/2)], built directly (identical to R_y gates on |0...0>)."""
    B, n = phi.shape
    a = np.stack([np.cos(phi / 2), np.sin(phi / 2)], -1)          # (B, n, 2)
    s = a[:, 0]
    for k in range(1, n):
        s = np.reshape(s[:, :, None] * a[:, k][:, None, :], (B, -1))
    return s


def zz_feature_map(phi):
    """Second-order Pauli-Z feature map (ZZFeatureMap, reps=1, linear entanglement)."""
    B, n = phi.shape
    s = zero_state(B, n)
    for k in range(n):
        s = hadamard(s, k)
        s = rz(s, k, 2.0 * phi[:, k])
    for k in range(n - 1):
        s = cnot(s, k, k + 1)
        s = rz(s, k + 1, 2.0 * (math.pi - phi[:, k]) * (math.pi - phi[:, k + 1]))
        s = cnot(s, k, k + 1)
    return s


def real_amplitudes(state, theta, reps):
    """RealAmplitudes ansatz (R_y layers + linear CNOT chain); theta has (reps+1)*n entries.
    The circuit does not depend on the data, so its unitary U is built once (by acting on the
    computational basis) and applied to the whole batch as a matrix product."""
    n = _n(state)
    U = _real_amplitudes_gates(onp.eye(2 ** n), theta, reps)      # row i = U|i>
    return np.dot(state, U)


def _real_amplitudes_gates(state, theta, reps):
    n = _n(state)
    i = 0
    for r in range(reps + 1):
        for k in range(n):
            state = ry(state, k, theta[i]); i += 1
        if r < reps:
            for k in range(n - 1):
                state = cnot(state, k, k + 1)
    return state


def n_ansatz(reps, n=N):
    return (reps + 1) * n
