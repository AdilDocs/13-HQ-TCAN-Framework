"""Select the best configuration per model family on the VALIDATION year, then run the final
3-seed evaluation on the test year.  usage: python final_all.py <family> [<family> ...]"""
import glob, json, sys
import tune

FIXED = {
    "lgbm": None,                        # chosen from search
    "logreg": dict(kind="logreg"),
    "persistence": dict(kind="persistence"),
    "vqc": dict(kind="vqc"),
    "qsann": dict(kind="qsann"),
    "hqtcn": dict(kind="hqtcn"),
}


def best(kind):
    recs = [json.load(open(f)) for f in glob.glob(f"{tune.OUT}/search_kind-{kind}_*.json")]
    recs = [r for r in recs if r["cfg"]["kind"] == kind]
    r = max(recs, key=lambda r: r["val"]["PR_AUC"])
    print(f"selected for {kind}: {r['cfg']} (val PR-AUC {r['val']['PR_AUC']:.4f}, of {len(recs)} configs)", flush=True)
    return r["cfg"]


if __name__ == "__main__":
    for fam in sys.argv[1:]:
        cfg = FIXED.get(fam) or best(fam)
        seeds = (0,) if fam == "persistence" else (0, 1, 2)
        if fam == "logreg":
            seeds = (0,)
        for s in seeds:
            tune.final(cfg, s)
