"""Aggregate cached results into tables (CSV + LaTeX rows) and IEEE-style figures."""
import glob, json, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.makedirs("figs", exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 8,
                     "axes.labelsize": 8, "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
                     "xtick.direction": "in", "ytick.direction": "in", "axes.linewidth": 0.6,
                     "savefig.dpi": 300, "savefig.bbox": "tight"})
COL = {"HQ-TCAN (proposed)": "#c0392b", "TCN + classical attention": "#2c6fbb", "LightGBM": "#2e8b57",
       "Persistence": "#7f7f7f", "Logistic regression": "#8e6cbb"}

def load_results(pattern="results/*.json"):
    recs = [json.load(open(f)) for f in glob.glob(pattern)]
    if not recs:                      # nothing run yet: empty frame with the expected columns
        return pd.DataFrame(columns=["model", "h", "pct", "lam", "seed", "hist", "zeta"])
    df = pd.DataFrame(recs)
    return pd.concat([df.drop(columns=["metrics"]), pd.json_normalize(df["metrics"])], axis=1)


R = load_results()
KEYS = ["TCR", "SPE", "GMean", "FSS", "FA", "PR_AUC", "ROC_AUC", "Brier", "N_theta", "PER"]


def agg(df):
    g = df.groupby("model")[[k for k in KEYS if k in df]].agg(["mean", "std", "count"])
    return g


def table(df, order, fname):
    rows = []
    for m in order:
        d = df[df.model == m]
        if d.empty:
            continue
        row = {"Model": m, "seeds": len(d)}
        for k in ["TCR", "SPE", "GMean", "FSS", "FA", "PR_AUC", "ROC_AUC", "Brier", "N_theta", "PER"]:
            if k in d and d[k].notna().any():
                row[k] = d[k].mean(); row[k + "_sd"] = d[k].std(ddof=1) if len(d) > 1 else 0.0
        rows.append(row)
    t = pd.DataFrame(rows)
    t.to_csv(f"figs/{fname}.csv", index=False)
    return t


if __name__ == "__main__":
    base = R[(R.h == 6) & (R.pct == 90) & (R.lam == 3.0)]
    main_order = ["HQ-TCAN (proposed)", "TCN + classical attention", "LSTM [6]", "Transformer [9]",
                  "VQC [12]", "HQTCN [14]", "QSANN [24]", "LightGBM", "Logistic regression", "Persistence"]
    print(table(base, main_order, "table_main").round(4).to_string())
    abl_order = ["HQ-TCAN (proposed)", "w/o quantum attention", "classical attention + VQC",
                 "w/o dilation", "classical readout"]
    abl = pd.concat([base[base.model.isin(abl_order)],
                     R[(R.model == "HQ-TCAN (proposed)") & (R.h == 6) & (R.pct == 90) & (R.lam == 0.0)]
                     .assign(model="w/o severity weighting (lambda=0)")])
    print(table(abl, abl_order + ["w/o severity weighting (lambda=0)"], "table_ablation").round(4).to_string())


# ------------------------------- figures -------------------------------

def fig_timeseries():
    sim = pd.read_pickle("sim.pkl")
    zeta = float(np.percentile(sim.loc["2015":"2017", "ENS"], 90))
    w = sim.loc["2019-01-14":"2019-01-27"]
    fig, ax = plt.subplots(2, 1, figsize=(3.5, 3.4), sharex=True, gridspec_kw={"height_ratios": [1.6, 1]})
    ax[0].plot(w.index, w.L / 1e3, color="k", lw=0.9, label="Load $L$")
    ax[0].plot(w.index, w.P_p / 1e3, color="#e69f00", lw=0.8, label="PV $P_p$")
    ax[0].plot(w.index, w.P_w / 1e3, color="#2c6fbb", lw=0.8, label="Wind $P_w$")
    ax[0].plot(w.index, w.B / 1e3, color="#2e8b57", lw=0.8, ls="--", label="BESS SoC $B$ (GWh)")
    ax[0].set_ylabel("Power (GW)")
    ax[0].legend(ncol=2, frameon=False, loc="upper right")
    ax[1].fill_between(w.index, 0, w.ENS / 1e3, color="#c0392b", alpha=0.35, lw=0)
    ax[1].plot(w.index, w.ENS / 1e3, color="#c0392b", lw=0.6)
    ax[1].axhline(zeta / 1e3, color="k", ls=":", lw=0.8)
    ax[1].text(w.index[5], zeta / 1e3 + 0.8, r"$\zeta_{0.9}$", fontsize=7)
    ax[1].set_ylabel("ENS (GWh)")
    ax[1].tick_params(axis="x", rotation=30)
    fig.savefig("figs/fig_timeseries.png"); plt.close(fig)


def fig_convergence():
    sub = R[(R.h == 6) & (R.pct == 90) & (R.lam == 3.0)]
    fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.4))
    for name, ls in [("HQ-TCAN (proposed)", "-"), ("TCN + classical attention", "--")]:
        H = [h for h in sub[sub.model == name]["hist"] if isinstance(h, dict)]
        if not H:
            continue
        n = min(len(h["train_loss"]) for h in H)
        for key, lab, c in [("train_loss", "train", COL[name]), ("val_loss", "val", COL[name])]:
            a = np.array([h[key][:n] for h in H])
            mu, sd = a.mean(0), a.std(0)
            x = np.arange(1, n + 1)
            ax[0].plot(x, mu, ls=ls if key == "train_loss" else ":", color=c, lw=1.0,
                       label=f"{name.split(' (')[0]} ({lab})")
            ax[0].fill_between(x, mu - sd, mu + sd, color=c, alpha=0.12, lw=0)
        for key, c in [("val_tcr", "#c0392b"), ("val_spe", "#2c6fbb"), ("val_gmean", "k")]:
            if name != "HQ-TCAN (proposed)":
                continue
            a = np.array([h[key][:n] for h in H]); x = np.arange(1, n + 1)
            ax[1].plot(x, a.mean(0), color=c, lw=1.0, label={"val_tcr": "TCR", "val_spe": "SPE",
                                                              "val_gmean": "G-Mean"}[key])
            ax[1].fill_between(x, a.mean(0) - a.std(0), a.mean(0) + a.std(0), color=c, alpha=0.12, lw=0)
        if name == "HQ-TCAN (proposed)":
            a = np.array([h["val_prauc"][:n] for h in H])
            ax[1].plot(x, a.mean(0), color="#2e8b57", lw=1.0, ls="--", label="PR-AUC")
    ax[0].set_xlabel("Epoch"); ax[0].set_ylabel("Risk-aware loss"); ax[0].legend(frameon=False)
    ax[1].set_xlabel("Epoch"); ax[1].set_ylabel("Validation index (HQ-TCAN)"); ax[1].set_ylim(0.4, 1.0)
    ax[1].legend(frameon=False, ncol=2, loc="lower right")
    fig.savefig("figs/fig_convergence.png"); plt.close(fig)


def _sens(var, values, fixed, models, metric):
    out = {}
    for m in models:
        mu, sd = [], []
        for v in values:
            q = dict(fixed, **{var: v})
            d = R[(R.model == m) & (R.h == q["h"]) & (R.pct == q["pct"]) & (R.lam == q["lam"])]
            mu.append(d[metric].mean() if len(d) else np.nan)
            sd.append(d[metric].std(ddof=0) if len(d) > 1 else 0.0)
        out[m] = (np.array(mu), np.array(sd))
    return out


def fig_sensitivity():
    models = ["HQ-TCAN (proposed)", "TCN + classical attention", "LightGBM", "Persistence"]
    fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.4))
    fig.subplots_adjust(wspace=0.38)
    for j, (var, vals, lab) in enumerate([("pct", [85, 90, 95, 97.5, 99], r"ENS percentile $\alpha$ (%)"),
                                          ("h", [1, 3, 6, 12, 24], "Forecast horizon $h$ (h)")]):
        res = _sens(var, vals, {"h": 6, "pct": 90, "lam": 3.0}, models, "GMean")
        for m, (mu, sd) in res.items():
            ax[j].errorbar(vals, mu, yerr=sd, color=COL[m], marker="o", ms=2.5, lw=0.9, capsize=1.5,
                           label=m.replace(" (proposed)", ""))
        ax[j].set_xlabel(lab); ax[j].set_ylabel("Test G-Mean")
        ax[j].set_title("(" + "ab"[j] + ")", fontsize=8)
    ax[0].legend(frameon=False, fontsize=6, loc="lower left")
    lams = [0.0, 1.0, 3.0, 5.0]
    for metric, c, lab in [("TCR", "#c0392b", "TCR"), ("SPE", "#2c6fbb", "SPE"), ("PR_AUC", "#2e8b57", "PR-AUC")]:
        mu, sd = _sens("lam", lams, {"h": 6, "pct": 90, "lam": 3.0}, ["HQ-TCAN (proposed)"], metric)["HQ-TCAN (proposed)"]
        ax[2].errorbar(lams, mu, yerr=sd, color=c, marker="o", ms=2.5, lw=0.9, capsize=1.5, label=lab)
    ax[2].set_xlabel(r"Severity weight $\lambda$"); ax[2].set_ylabel("HQ-TCAN test index")
    ax[2].legend(frameon=False); ax[2].set_title("(c)", fontsize=8)
    fig.savefig("figs/fig_sensitivity.png"); plt.close(fig)
