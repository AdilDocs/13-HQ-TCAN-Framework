"""Tuning round. Stage 'search' sees ONLY the validation year (no test predictions are made).
Stage 'final' retrains the selected configurations with 3 seeds and evaluates on the test year.

usage: python tune.py search <group>    (hq | twin | rnn | gbm)
       python tune.py final <model-key>
"""
import json, os, sys, time, pickle
import numpy as np
from train import prepare, train_cfg, full_eval, make_predict, risk_weights, best_threshold, metrics
from models import n_params

OUT = "results_v2"
os.makedirs(OUT, exist_ok=True)
LAM = 1.0                      # selected on validation in the lambda study
D = prepare(h=6, pct=90)

GRIDS = {
    "hq": [dict(kind="hqtcan2", nq=q, heads=hh, pool=p) for q in (4, 6) for hh in (1, 2) for p in ("last", "both")],
    "twin": [dict(kind="twin2", nq=q, heads=hh, pool=p) for q in (4, 6) for hh in (1, 2) for p in ("last", "both")],
    "rnn": [dict(kind="lstm", hidden=h) for h in (32, 64)] + [dict(kind="transformer", d=d) for d in (16, 32)],
    "gbm": [dict(kind="lgbm", leaves=l, n_est=n) for l in (15, 31, 63) for n in (300, 600)],
}


def key(cfg):
    return "_".join(f"{k}-{v}" for k, v in cfg.items())


def lgbm_fit(cfg, seed):
    import lightgbm as lgb
    tr = D["train"]
    Xtr = tr["X"].reshape(len(tr["X"]), -1)
    pos_w = float((tr["y"] == 0).sum() / (tr["y"] == 1).sum())
    w = np.asarray(risk_weights(tr["y"], tr["ens"], D["zeta"], LAM, pos_w))
    m = lgb.LGBMClassifier(n_estimators=cfg["n_est"], learning_rate=0.05, num_leaves=cfg["leaves"],
                           subsample=0.8, subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1)
    return m.fit(Xtr, tr["y"], sample_weight=w)


def search(group):
    for cfg in GRIDS[group]:
        path = f"{OUT}/search_{key(cfg)}.json"
        if os.path.exists(path):
            continue
        t0 = time.time()
        Xv, yv = D["val"]["X"], D["val"]["y"]
        if cfg["kind"] == "lgbm":
            sv = lgbm_fit(cfg, 0).predict_proba(Xv.reshape(len(Xv), -1))[:, 1]
            hist, npar = None, None
        else:
            params, apply, hist = train_cfg(cfg, D, lam=LAM, seed=0)
            sv = make_predict(apply)(params, Xv)
            npar = n_params(params)
        mv = metrics(sv, yv, best_threshold(sv, yv))           # VALIDATION ONLY
        rec = dict(cfg=cfg, val=mv, n_params=npar, hist=hist, sec=time.time() - t0)
        json.dump(rec, open(path, "w"))
        print(f"SEARCH {key(cfg):40s} valAP {mv['PR_AUC']:.4f} valG {mv['GMean']:.4f} "
              f"N {npar} ({time.time()-t0:.0f}s)", flush=True)


def final(cfg, seed):
    path = f"{OUT}/final_{key(cfg)}_s{seed}.json"
    if os.path.exists(path):
        return json.load(open(path))
    t0 = time.time()
    Xv, Xt = D["val"]["X"], D["test"]["X"]
    if cfg["kind"] == "lgbm":
        m = lgbm_fit(cfg, seed)
        sv, st = (m.predict_proba(x.reshape(len(x), -1))[:, 1] for x in (Xv, Xt))
        res, tau = full_eval(sv, st, D, None, logits=False)
        hist = None
    elif cfg["kind"] in ("logreg", "persistence"):
        if cfg["kind"] == "persistence":
            sv, st = D["val"]["persist"], D["test"]["persist"]; nt = None
        else:
            from sklearn.linear_model import LogisticRegression
            tr = D["train"]; Xtr = tr["X"].reshape(len(tr["X"]), -1)
            pos_w = float((tr["y"] == 0).sum() / (tr["y"] == 1).sum())
            w = np.asarray(risk_weights(tr["y"], tr["ens"], D["zeta"], LAM, pos_w))
            m = LogisticRegression(max_iter=3000).fit(Xtr, tr["y"], sample_weight=w)
            sv, st = (m.decision_function(x.reshape(len(x), -1)) for x in (Xv, Xt)); nt = Xtr.shape[1] + 1
        res, tau = full_eval(sv, st, D, nt, logits=False)
        hist = None
    else:
        params, apply, hist = train_cfg(cfg, D, lam=LAM, seed=seed)
        pr = make_predict(apply)
        sv, st = pr(params, Xv), pr(params, Xt)
        res, tau = full_eval(sv, st, D, n_params(params))
        if seed == 0:
            pickle.dump(params, open(f"{OUT}/params_{key(cfg)}.pkl", "wb"))
    np.savez(f"{OUT}/scores_{key(cfg)}_s{seed}.npz", val=sv, test=st)
    rec = dict(cfg=cfg, seed=seed, tau=tau, metrics=res, hist=hist, sec=time.time() - t0)
    json.dump(rec, open(path, "w"))
    print(f"FINAL {key(cfg):40s} s{seed} G {res['GMean']:.4f} TCR {res['TCR']:.4f} SPE {res['SPE']:.4f} "
          f"FSS {res['FSS']:.0f} AP {res['PR_AUC']:.4f} TCR@SPE90 {res['TCR_at_SPE90']:.4f} "
          f"({time.time()-t0:.0f}s)", flush=True)
    return rec


if __name__ == "__main__":
    if sys.argv[1] == "search":
        search(sys.argv[2])
    else:
        cfg = json.loads(sys.argv[2])
        for s in (0, 1, 2):
            final(cfg, s)
