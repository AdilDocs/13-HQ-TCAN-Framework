"""Final (tuned) comparison table + moving-block bootstrap of G-Mean / TCR differences vs HQ-TCAN."""
import glob, json
import numpy as np
import pandas as pd
from train import prepare

OUT = "results_v2"
D = prepare(h=6, pct=90)
yt = D["test"]["y"].astype(int)

NAMES = {"hqtcan2": "HQ-TCAN (proposed)", "twin2": "TCN + classical attention", "lstm": "LSTM [6]",
         "transformer": "Transformer [9]", "vqc": "VQC [12]", "hqtcn": "HQTCN [14]", "qsann": "QSANN [24]",
         "lgbm": "LightGBM", "logreg": "Logistic regression", "persistence": "Persistence"}
ORDER = list(NAMES)


def load():
    recs = [json.load(open(f)) for f in glob.glob(f"{OUT}/final_*.json")]
    rows = []
    for r in recs:
        m = dict(r["metrics"]); m["kind"] = r["cfg"]["kind"]; m["seed"] = r["seed"]; m["tau"] = r["tau"]
        m["cfg"] = json.dumps(r["cfg"]); m["sec_per_ep"] = np.mean(r["hist"]["sec"]) if r["hist"] else np.nan
        rows.append(m)
    return pd.DataFrame(rows), recs


def preds(rec):
    from tune import key
    z = np.load(f"{OUT}/scores_{key(rec['cfg'])}_s{rec['seed']}.npz")
    return z["test"] >= rec["tau"]


def block_bootstrap(P_a, P_b, n_boot=2000, block=24, seed=0):
    """P_a, P_b: lists of boolean prediction vectors (one per seed). Returns CI of mean-over-seeds
    differences in G-Mean and TCR (a - b), resampling 24-h blocks of test hours."""
    rng = np.random.default_rng(seed)
    T = len(yt); nb = int(np.ceil(T / block))
    starts = np.arange(0, T - block + 1)

    def gm(P, idx):
        y = yt[idx]; out_g, out_t = [], []
        for p in P:
            q = p[idx]; tcr = q[y == 1].mean(); spe = (~q[y == 0]).mean()
            out_g.append(np.sqrt(tcr * spe)); out_t.append(tcr)
        return np.mean(out_g), np.mean(out_t)
    dg, dt = [], []
    for _ in range(n_boot):
        idx = np.concatenate([np.arange(s, s + block) for s in rng.choice(starts, nb)])[:T]
        ga, ta = gm(P_a, idx); gb, tb = gm(P_b, idx)
        dg.append(ga - gb); dt.append(ta - tb)
    full = np.arange(T)
    ga, ta = gm(P_a, full); gb, tb = gm(P_b, full)
    return (ga - gb, *np.percentile(dg, [2.5, 97.5]), np.mean(np.array(dg) <= 0),
            ta - tb, *np.percentile(dt, [2.5, 97.5]))


if __name__ == "__main__":
    df, recs = load()
    keys = ["TCR", "SPE", "GMean", "FSS", "FA", "PR_AUC", "ROC_AUC", "TCR_at_SPE90", "FSS_at_SPE90",
            "N_theta", "PER", "val_PR_AUC", "sec_per_ep"]
    g = df.groupby("kind")
    tab = []
    for k in ORDER:
        if k not in g.groups:
            continue
        d = g.get_group(k)
        row = {"Model": NAMES[k], "kind": k, "seeds": len(d), "cfg": d.cfg.iloc[0]}
        for c in keys:
            if c in d and d[c].notna().any():
                row[c] = d[c].mean(); row[c + "_sd"] = d[c].std(ddof=1) if len(d) > 1 else 0.0
        tab.append(row)
    tab = pd.DataFrame(tab)
    tab.to_csv("figs/table_final.csv", index=False)
    show = ["Model", "seeds", "GMean", "GMean_sd", "TCR", "SPE", "FSS", "FA", "PR_AUC", "PR_AUC_sd",
            "TCR_at_SPE90", "FSS_at_SPE90", "N_theta", "PER", "val_PR_AUC", "sec_per_ep"]
    print(tab[[c for c in show if c in tab]].round(4).to_string())

    # block bootstrap vs HQ-TCAN
    byk = {}
    for r in recs:
        byk.setdefault(r["cfg"]["kind"], []).append(r)
    PA = [preds(r) for r in byk["hqtcan2"]]
    out = []
    for k in ORDER[1:]:
        if k not in byk:
            continue
        d, lo, hi, p, dt, tlo, thi = block_bootstrap(PA, [preds(r) for r in byk[k]])
        out.append(dict(vs=NAMES[k], dG=d, dG_lo=lo, dG_hi=hi, p_le0=p, dTCR=dt, dTCR_lo=tlo, dTCR_hi=thi))
    bt = pd.DataFrame(out)
    bt.to_csv("figs/table_bootstrap.csv", index=False)
    print(bt.round(4).to_string())


def fig_convergence_v2():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import analyze  # noqa: F401  (style)
    recs = [json.load(open(f)) for f in glob.glob(f"{OUT}/final_*.json")]
    H = {k: [r["hist"] for r in recs if r["cfg"]["kind"] == k and r["hist"]] for k in ("hqtcan2", "twin2")}
    fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.4))
    fig.subplots_adjust(wspace=0.28)
    col = {"hqtcan2": "#c0392b", "twin2": "#2c6fbb"}
    lab = {"hqtcan2": "HQ-TCAN", "twin2": "Classical twin"}
    for k, hs in H.items():
        n = min(len(h["train_loss"]) for h in hs); x = np.arange(1, n + 1)
        for key, ls, suf in [("train_loss", "-", "train"), ("val_loss", ":", "val")]:
            a = np.array([h[key][:n] for h in hs])
            ax[0].plot(x, a.mean(0), ls=ls, color=col[k], lw=1.0, label=f"{lab[k]} ({suf})")
            ax[0].fill_between(x, a.mean(0) - a.std(0), a.mean(0) + a.std(0), color=col[k], alpha=0.12, lw=0)
    hs = H["hqtcan2"]; n = min(len(h["train_loss"]) for h in hs); x = np.arange(1, n + 1)
    for key, c, l in [("val_tcr", "#c0392b", "TCR"), ("val_spe", "#2c6fbb", "SPE"), ("val_gmean", "k", "G-Mean"),
                      ("val_prauc", "#2e8b57", "PR-AUC")]:
        a = np.array([h[key][:n] for h in hs])
        ax[1].plot(x, a.mean(0), color=c, lw=1.0, ls="--" if key == "val_prauc" else "-", label=l)
        ax[1].fill_between(x, a.mean(0) - a.std(0), a.mean(0) + a.std(0), color=c, alpha=0.12, lw=0)
    ax[0].set_xlabel("Epoch"); ax[0].set_ylabel("Risk-aware loss"); ax[0].legend(frameon=False); ax[0].set_title("(a)", fontsize=8)
    ax[1].set_xlabel("Epoch"); ax[1].set_ylabel("HQ-TCAN validation index"); ax[1].set_ylim(0.4, 1.0)
    ax[1].legend(frameon=False, ncol=2, loc="lower right"); ax[1].set_title("(b)", fontsize=8)
    fig.savefig("figs/fig_convergence.png"); plt.close(fig)
    for k, hs in H.items():
        print(k, "epochs run", [len(h["sec"]) for h in hs], "best", [h.get("best_epoch") for h in hs],
              "sec/ep %.1f" % np.mean([np.mean(h["sec"]) for h in hs]),
              "final lr", [h["lr"][-1] for h in hs],
              "max val G", [round(max(h["val_gmean"]), 3) for h in hs])
