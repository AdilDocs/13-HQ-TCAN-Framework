"""HQ-TCAN, ablations and comparison models (autograd/NumPy, functional).

Each model is a pair (init(rng, f_in, K) -> params dict, apply(params, x) -> logits), x: (B, K, F).
"""
import math
import numpy as onp
import autograd.numpy as np
import qsim

NQ = qsim.N
PI = math.pi
NEG = -1e9


def sigmoid(x):
    return 0.5 * (np.tanh(0.5 * x) + 1.0)


def relu(x):
    return np.maximum(x, 0.0)


def softmax(x, mask=None):
    if mask is not None:
        x = np.where(mask, x, NEG)
    x = x - np.max(x, axis=-1, keepdims=True)
    e = np.exp(x)
    return e / np.sum(e, axis=-1, keepdims=True)


def causal_mask(K):
    return onp.tril(onp.ones((K, K), bool))


def _u(rng, shape, fan_in):
    b = 1.0 / math.sqrt(fan_in)
    return rng.uniform(-b, b, shape)


def dense_init(rng, din, dout, bias=True):
    p = {"W": _u(rng, (din, dout), din)}
    if bias:
        p["b"] = _u(rng, (dout,), din)
    return p


def dense(p, x):
    y = np.dot(x, p["W"])
    return y + p["b"] if "b" in p else y


# ---------------------------- TCN ----------------------------

def conv_init(rng, cin, cout, k=3):
    return {"W": _u(rng, (k, cin, cout), cin * k), "b": _u(rng, (cout,), cin * k)}


def causal_conv(p, x, d):
    """Dilated causal convolution. x (B,K,C) -> (B,K,C_out); output at i uses inputs i, i-d, i-2d."""
    k = p["W"].shape[0]
    B, K, C = x.shape
    xp = np.concatenate([onp.zeros((B, (k - 1) * d, C)), x], axis=1)
    out = p["b"]
    for j in range(k):
        out = out + np.dot(xp[:, j * d: j * d + K, :], p["W"][j])
    return out


def tcn_init(rng, f_in, hidden=16, out=NQ):
    return {"c1": conv_init(rng, f_in, hidden), "c2": conv_init(rng, hidden, out)}


def tcn(p, x, dil=(1, 2)):
    return causal_conv(p["c2"], relu(causal_conv(p["c1"], x, dil[0])), dil[1])


# ---------------------------- attention ----------------------------

def qattn_init(rng, reps=1):
    n = qsim.n_ansatz(reps)
    return {k: rng.uniform(0, 2 * PI, n) for k in "qkv"}


def qattn(p, h, reps=1, return_w=False):
    """QSANN-style quantum self-attention: Gaussian projected kernel, causal mask, residual."""
    B, K, _ = h.shape
    psi = qsim.angle_encoding(PI * sigmoid(np.reshape(h, (B * K, NQ))))
    q = np.reshape(qsim.expval_z(qsim.real_amplitudes(psi, p["q"], reps), (0,)), (B, K))
    k = np.reshape(qsim.expval_z(qsim.real_amplitudes(psi, p["k"], reps), (0,)), (B, K))
    v = np.reshape(qsim.expval_z(qsim.real_amplitudes(psi, p["v"], reps), range(NQ)), (B, K, NQ))
    score = -(q[:, :, None] - k[:, None, :]) ** 2
    w = softmax(score, causal_mask(K))
    out = h + np.einsum("bij,bjd->bid", w, v)
    return (out, w) if return_w else out


def cattn_init(rng, d=NQ, dk=1):
    return {"q": dense_init(rng, d, dk, False), "k": dense_init(rng, d, dk, False),
            "v": dense_init(rng, d, d, False)}


def cattn(p, h):
    """Classical twin: single-head scaled dot-product attention, causal mask, residual."""
    K = h.shape[1]
    dk = p["q"]["W"].shape[1]
    s = np.einsum("bid,bjd->bij", dense(p["q"], h), dense(p["k"], h)) / math.sqrt(dk)
    return h + np.einsum("bij,bjd->bid", softmax(s, causal_mask(K)), dense(p["v"], h))


# ---------------------------- VQC readout ----------------------------

def vqc_init(rng, reps=2):
    return {"theta": rng.uniform(0, 2 * PI, qsim.n_ansatz(reps)), "kappa": onp.array(3.0),
            "b": onp.array(0.0)}


def vqc(p, y, reps=2):
    """ZZ feature map + RealAmplitudes(reps=2); logit = kappa * <Z_0> + b."""
    s = qsim.real_amplitudes(qsim.zz_feature_map(PI * sigmoid(y)), p["theta"], reps)
    return p["kappa"] * qsim.expval_z(s, (0,))[:, 0] + p["b"]


def reup_init(rng, layers=3):
    return {"w": rng.normal(1.0, 0.1, (layers, NQ)), "c": rng.uniform(0, 2 * PI, (layers, NQ)),
            "last": rng.uniform(0, 2 * PI, NQ), "kappa": onp.array(3.0), "b": onp.array(0.0)}


def reup(p, y):
    """Data re-uploading classifier (Perez-Salinas et al. [17]): the input is encoded L times,
    R_y(w_lk * phi_k + c_lk) on each qubit followed by a CNOT chain; logit = kappa <Z_0> + b."""
    phi = PI * sigmoid(y)
    s = qsim.zero_state(y.shape[0])
    for l in range(p["w"].shape[0]):
        for k in range(NQ):
            s = qsim.ry(s, k, p["w"][l, k] * phi[:, k] + p["c"][l, k])
        for k in range(NQ - 1):
            s = qsim.cnot(s, k, k + 1)
    for k in range(NQ):
        s = qsim.ry(s, k, p["last"][k])
    return p["kappa"] * qsim.expval_z(s, (0,))[:, 0] + p["b"]


# ---------------------------- HQ-TCAN family ----------------------------

def hqtcan(attention="quantum", dil=(1, 2), readout="quantum", use_tcn=True):
    def init(rng, f_in, K):
        p = {"enc": tcn_init(rng, f_in) if use_tcn else dense_init(rng, f_in, NQ)}
        if attention == "quantum":
            p["attn"] = qattn_init(rng)
        elif attention == "classical":
            p["attn"] = cattn_init(rng)
        p["head"] = {"quantum": lambda: vqc_init(rng), "reup": lambda: reup_init(rng),
                     "classical": lambda: dense_init(rng, NQ, 1)}[readout]()
        return p

    def apply(p, x):
        h = tcn(p["enc"], x, dil) if use_tcn else dense(p["enc"], x)
        if attention == "quantum":
            h = qattn(p["attn"], h)
        elif attention == "classical":
            h = cattn(p["attn"], h)
        y = h[:, -1, :]
        if readout == "quantum":
            return vqc(p["head"], y)
        if readout == "reup":
            return reup(p["head"], y)
        return dense(p["head"], y)[:, 0]
    return init, apply


# ---------------------------- external baselines ----------------------------

def lstm_net(hidden=32):                                  # after Wen et al. [6]
    def init(rng, f_in, K):
        return {"Wx": _u(rng, (f_in, 4 * hidden), hidden), "Wh": _u(rng, (hidden, 4 * hidden), hidden),
                "b": onp.zeros(4 * hidden), "fc": dense_init(rng, hidden, 1)}

    def apply(p, x):
        B, K, _ = x.shape
        h = onp.zeros((B, hidden)); c = onp.zeros((B, hidden))
        H = hidden
        for t in range(K):
            g = np.dot(x[:, t], p["Wx"]) + np.dot(h, p["Wh"]) + p["b"]
            i, f, gg, o = g[:, :H], g[:, H:2 * H], g[:, 2 * H:3 * H], g[:, 3 * H:]
            c = sigmoid(f + 1.0) * c + sigmoid(i) * np.tanh(gg)
            h = sigmoid(o) * np.tanh(c)
        return dense(p["fc"], h)[:, 0]
    return init, apply


def _ln(x, g, b):
    m = np.mean(x, -1, keepdims=True)
    v = np.mean((x - m) ** 2, -1, keepdims=True)
    return (x - m) / np.sqrt(v + 1e-5) * g + b


def transformer_net(d=16, heads=2, ff=32):               # after Li et al. [9]
    def init(rng, f_in, K):
        return {"inp": dense_init(rng, f_in, d), "pos": 0.02 * rng.standard_normal((K, d)),
                "qkv": dense_init(rng, d, 3 * d), "o": dense_init(rng, d, d),
                "f1": dense_init(rng, d, ff), "f2": dense_init(rng, ff, d),
                "g1": onp.ones(d), "b1": onp.zeros(d), "g2": onp.ones(d), "b2": onp.zeros(d),
                "fc": dense_init(rng, d, 1)}

    def apply(p, x):
        B, K, _ = x.shape
        dh = d // heads
        h = dense(p["inp"], x) + p["pos"][:K]
        qkv = dense(p["qkv"], h)
        heads_out = []
        for j in range(heads):
            q = qkv[:, :, j * dh:(j + 1) * dh]
            k = qkv[:, :, d + j * dh: d + (j + 1) * dh]
            v = qkv[:, :, 2 * d + j * dh: 2 * d + (j + 1) * dh]
            s = np.einsum("bid,bjd->bij", q, k) / math.sqrt(dh)
            heads_out.append(np.einsum("bij,bjd->bid", softmax(s, causal_mask(K)), v))
        a = np.concatenate(heads_out, -1)
        h = _ln(h + dense(p["o"], a), p["g1"], p["b1"])
        h = _ln(h + dense(p["f2"], relu(dense(p["f1"], h))), p["g2"], p["b2"])
        return dense(p["fc"], h[:, -1])[:, 0]
    return init, apply


def vqc_net():                                           # quantum time-series model, after Habibi et al. [12]
    def init(rng, f_in, K):
        return {"comp": dense_init(rng, f_in * K, NQ), "head": vqc_init(rng)}

    def apply(p, x):
        return vqc(p["head"], dense(p["comp"], np.reshape(x, (x.shape[0], -1))))
    return init, apply


def _qconv_init(rng, cin, reps=1):
    return {"proj": dense_init(rng, cin, 2), "theta": rng.uniform(0, 2 * PI, qsim.n_ansatz(reps))}


def _qconv(p, x, d, reps=1, cout=2):
    """Quantum dilated temporal convolution, kernel 2: (z_t, z_{t-d}) -> 4-qubit VQC."""
    B, K, _ = x.shape
    z = dense(p["proj"], x)
    zp = np.concatenate([onp.zeros((B, d, 2)), z[:, :K - d]], axis=1)
    phi = PI * sigmoid(np.reshape(np.concatenate([z, zp], -1), (B * K, NQ)))
    s = qsim.real_amplitudes(qsim.angle_encoding(phi), p["theta"], reps)
    return np.reshape(qsim.expval_z(s, range(cout)), (B, K, cout))


def hqtcn_net():                                         # hybrid quantum TCN, after Park et al. [14]
    def init(rng, f_in, K):
        return {"q1": _qconv_init(rng, f_in), "q2": _qconv_init(rng, 2), "fc": dense_init(rng, 2, 1)}

    def apply(p, x):
        h = _qconv(p["q2"], _qconv(p["q1"], x, 1), 2)
        return dense(p["fc"], h[:, -1])[:, 0]
    return init, apply


MODELS = {
    "HQ-TCAN (proposed)": lambda: hqtcan(),
    "TCN + classical attention": lambda: hqtcan("classical", readout="classical"),
    "LSTM [6]": lstm_net,
    "Transformer [9]": transformer_net,
    "VQC [12]": vqc_net,
    "HQTCN [14]": hqtcn_net,
    "QSANN [24]": lambda: hqtcan(use_tcn=False),
    "HQ-TCAN-RU": lambda: hqtcan(readout="reup"),
    # ablations
    "w/o quantum attention": lambda: hqtcan("none"),
    "classical attention + VQC": lambda: hqtcan("classical"),
    "w/o dilation": lambda: hqtcan(dil=(1, 1)),
    "classical readout": lambda: hqtcan(readout="classical"),
}


def build_model(name):
    return MODELS[name]()


def n_params(p):
    from autograd.misc import flatten
    return int(flatten(p)[0].size)


# ======================= tunable HQ-TCAN (v2) and its classical twin =======================

def qattn_mh_init(rng, nq, heads, reps=1):
    n = qsim.n_ansatz(reps, nq)
    return [{k: rng.uniform(0, 2 * PI, n) for k in "qkv"} for _ in range(heads)]


def qattn_mh(P, h, reps=1, return_w=False):
    """Multi-head QSANN-style quantum self-attention (Gaussian projected kernel, causal mask).
    Each head has its own U_Q, U_K, U_V; head outputs are averaged and added residually."""
    B, K, nq = h.shape
    psi = qsim.angle_encoding(PI * sigmoid(np.reshape(h, (B * K, nq))))
    mask = causal_mask(K)
    acc, ws = 0.0, []
    for p in P:
        q = np.reshape(qsim.expval_z(qsim.real_amplitudes(psi, p["q"], reps), (0,)), (B, K))
        k = np.reshape(qsim.expval_z(qsim.real_amplitudes(psi, p["k"], reps), (0,)), (B, K))
        v = np.reshape(qsim.expval_z(qsim.real_amplitudes(psi, p["v"], reps), range(nq)), (B, K, nq))
        w = softmax(-(q[:, :, None] - k[:, None, :]) ** 2, mask)
        ws.append(w)
        acc = acc + np.einsum("bij,bjd->bid", w, v)
    out = h + acc / len(P)
    return (out, ws) if return_w else out


def cattn_mh_init(rng, d, heads):
    return [cattn_init(rng, d, 1) for _ in range(heads)]


def cattn_mh(P, h):
    K = h.shape[1]
    acc = 0.0
    for p in P:
        s = np.einsum("bid,bjd->bij", dense(p["q"], h), dense(p["k"], h))
        acc = acc + np.einsum("bij,bjd->bid", softmax(s, causal_mask(K)), dense(p["v"], h))
    return h + acc / len(P)


def _pool(h, pool):
    if pool == "last":
        return h[:, -1, :]
    if pool == "mean":
        return np.mean(h, axis=1)
    return 0.5 * (h[:, -1, :] + np.mean(h, axis=1))          # "both"


def hqtcan2(nq=4, heads=1, pool="last", attention="quantum", readout="quantum", hidden=16):
    def init(rng, f_in, K):
        p = {"enc": tcn_init(rng, f_in, hidden, nq)}
        p["attn"] = qattn_mh_init(rng, nq, heads) if attention == "quantum" else cattn_mh_init(rng, nq, heads)
        if readout == "quantum":
            p["head"] = {"theta": rng.uniform(0, 2 * PI, qsim.n_ansatz(2, nq)),
                         "kappa": onp.array(3.0), "b": onp.array(0.0)}
        else:
            p["head"] = dense_init(rng, nq, 1)
        return p

    def apply(p, x):
        h = tcn(p["enc"], x)
        h = qattn_mh(p["attn"], h) if attention == "quantum" else cattn_mh(p["attn"], h)
        y = _pool(h, pool)
        if readout == "quantum":
            return vqc(p["head"], y)
        return dense(p["head"], y)[:, 0]
    return init, apply


def build_from_config(cfg):
    """cfg: dict(kind='hqtcan2'|'twin2'|'lstm'|'transformer', ...)."""
    kind = cfg["kind"]
    if kind == "hqtcan2":
        return hqtcan2(cfg["nq"], cfg["heads"], cfg["pool"])
    if kind == "twin2":
        return hqtcan2(cfg["nq"], cfg["heads"], cfg["pool"], attention="classical", readout="classical")
    if kind == "lstm":
        return lstm_net(cfg["hidden"])
    if kind == "transformer":
        return transformer_net(cfg["d"], 2, 2 * cfg["d"])
    if kind == "vqc":
        return vqc_net()
    if kind == "qsann":
        return hqtcan(use_tcn=False)
    if kind == "hqtcn":
        return hqtcn_net()
    raise ValueError(kind)
