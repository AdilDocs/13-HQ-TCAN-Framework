"""Step 1: Grid scenario simulation and label generation (Methodology Sec. III-A, Eqs. 1-3)."""
import numpy as np
import pandas as pd

RAW = "data/time_series_60min_singleindex.csv"   # OPSD Time Series package, version 2020-10-06

# ---- Scenario parameters (high-renewable stress-test scenario of the German system) ----
P = dict(
    P_r=120_000.0,    # rated PV capacity [MW]
    R_std=1000.0,     # standard irradiance [W/m^2]
    R_c=150.0,        # threshold irradiance [W/m^2]
    C_w=110_000.0,    # installed wind capacity [MW]
    B_M=150_000.0,    # max BESS energy [MWh]
    B_m=15_000.0,     # min BESS energy [MWh]
    P_ch=30_000.0,    # max charging power [MW]
    P_dis=30_000.0,   # max discharging power [MW]
    eta_c=0.95,
    eta_d=0.90,
    G=None,           # firm dispatchable capacity [MW]; calibrated below if None
)


def load_opsd(path=RAW):
    cols = ["utc_timestamp", "DE_load_actual_entsoe_transparency",
            "DE_solar_profile", "DE_wind_profile"]
    df = pd.read_csv(path, usecols=cols, parse_dates=["utc_timestamp"])
    df = df.rename(columns={"DE_load_actual_entsoe_transparency": "L",
                            "DE_solar_profile": "cf_pv", "DE_wind_profile": "cf_w"})
    df = df[(df.utc_timestamp >= "2015-01-01") & (df.utc_timestamp < "2020-01-01")]
    df = df.set_index("utc_timestamp")
    n_missing = int(df.isna().sum().sum())
    df = df.interpolate(limit=6).dropna()
    df.attrs["n_missing_filled"] = n_missing
    return df


def pv_power(R, p):
    """Eq. (1): piecewise non-linear PV model."""
    out = np.where(R < p["R_c"], p["P_r"] * R**2 / (p["R_std"] * p["R_c"]),
                   np.where(R < p["R_std"], p["P_r"] * R / p["R_std"], p["P_r"]))
    return out


def simulate(df, p):
    """Eqs. (1)-(3) + ENS. Returns DataFrame with P_p, P_w, B, ENS."""
    # Irradiance-equivalent signal: OPSD provides the PV capacity factor, which is
    # mapped to an equivalent plane-of-array irradiance R(t) = CF_pv(t) * R_std.
    R = df["cf_pv"].clip(0, 1).values * p["R_std"]
    Pp = pv_power(R, p)
    Pw = p["C_w"] * df["cf_w"].clip(0, 1).values
    L = df["L"].values
    res = Pp + Pw
    T = len(L)
    B = np.empty(T); ENS = np.empty(T); Q = np.empty(T)
    b = 0.5 * (p["B_M"] + p["B_m"])
    for t in range(T):
        B[t] = b                                   # SoC at the start of hour t
        s = max(res[t] - L[t], 0.0)
        d = max(L[t] - res[t], 0.0)
        c = min(s, p["P_ch"], (p["B_M"] - b) / p["eta_c"])
        q = min(d, p["P_dis"], p["eta_d"] * (b - p["B_m"]))
        b = b + p["eta_c"] * c - q / p["eta_d"]
        Q[t] = q
        ENS[t] = max(d - q - p["G"], 0.0)
    out = df.copy()
    out["R"] = R; out["P_p"] = Pp; out["P_w"] = Pw; out["P_res"] = res
    out["B"] = B; out["q"] = Q; out["ENS"] = ENS
    return out


def calibrate_G(df, p, target=0.20, years=("2015", "2017")):
    """Pick firm capacity G so that ENS>0 in `target` share of TRAINING hours."""
    lo, hi = 0.0, 80_000.0
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        q = dict(p, G=mid)
        e = simulate(df, q).loc[years[0]:years[1], "ENS"]
        if (e > 0).mean() > target:
            lo = mid
        else:
            hi = mid
    return round(0.5 * (lo + hi), -2)


def build(p=P, target=0.20):
    df = load_opsd()
    if p["G"] is None:
        p = dict(p, G=calibrate_G(df, p, target))
    sim = simulate(df, p)
    sim.attrs.update(df.attrs)
    return sim, p


if __name__ == "__main__":
    sim, p = build()
    sim.to_pickle("sim.pkl")
    print("params:", p)
    tr = sim.loc["2015":"2017"]
    zeta = np.percentile(tr.ENS, 90)
    print("missing filled:", sim.attrs.get("n_missing_filled"), "rows:", len(sim))
    for y in ["2015", "2016", "2017", "2018", "2019"]:
        e = sim.loc[y, "ENS"]
        print(y, f"ENS>0 {100*(e>0).mean():.1f}%  EENS {e.sum()/1e6:.2f} TWh  "
                 f"tail(>=zeta) {100*(e>=zeta).mean():.1f}%  maxENS {e.max():.0f}")
    print("zeta_90 (train) =", round(zeta, 1))
    print(sim[["L", "P_p", "P_w", "B", "ENS"]].describe().round(1))
