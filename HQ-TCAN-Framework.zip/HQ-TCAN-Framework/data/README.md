Place the OPSD file here:

    time_series_60min_singleindex.csv

Source: Open Power System Data, Time Series package, version 2020-10-06
https://data.open-power-system-data.org/time_series/2020-10-06/

Columns used: utc_timestamp, DE_load_actual_entsoe_transparency,
DE_solar_profile, DE_wind_profile (years 2015-2019).
