"""Schematic of the HQ-TCAN framework (Fig. 1 of the methodology)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 6.4,
                     "mathtext.fontset": "dejavuserif"})
C_IN, C_CL, C_Q, C_OUT = "#eef2f7", "#dbe8f6", "#f9e3d6", "#e3f1e3"
EDGE = "#3a3a3a"

fig, ax = plt.subplots(figsize=(7.16, 3.3))
ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")


def box(x, y, w, h, fc, title=None, lines=(), fs=6.1, bold=True, ec=EDGE, lw=0.8, ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=0.8",
                                fc=fc, ec=ec, lw=lw, ls=ls))
    yy = y + h - 2.2
    if title:
        ax.text(x + w / 2, yy, title, ha="center", va="center", fontsize=fs + 0.3,
                fontweight="bold" if bold else "normal")
        yy -= 2.9
    for ln in lines:
        ax.text(x + w / 2, yy, ln, ha="center", va="center", fontsize=fs)
        yy -= 2.5


def arrow(x0, y0, x1, y1, txt=None, dy=1.4):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=8,
                                 lw=0.8, color=EDGE))
    if txt:
        ax.text((x0 + x1) / 2, (y0 + y1) / 2 + dy, txt, ha="center", va="bottom", fontsize=6.6)


# stage bands
for x, w, lab, c in [(0.5, 21, "(1) Physics & data", C_IN), (23, 19, "(2) Classical encoder", C_CL),
                     (43.5, 32, "(3) Quantum self-attention", C_Q), (77, 22.5, "(4) Quantum readout", C_OUT)]:
    ax.add_patch(FancyBboxPatch((x, 1), w, 37.5, boxstyle="round,pad=0,rounding_size=1.2",
                                fc=c, ec="none", alpha=0.45))
    ax.text(x + w / 2, 36.6, lab, ha="center", va="center", fontsize=6.8, fontweight="bold", color="#333")

# Stage 1
box(2, 22, 18, 12, "white", "Adequacy model",
    [r"PV $P_p(R)$, wind $C_wCF_w$", r"BESS: $c_t$, $q_t$, $B_{t+1}$", r"$\mathrm{ENS}_t=[d_t-q_t-G]^+$"])
box(2, 4, 18, 14, "white", "Labels & windows",
    [r"$S_t=\mathbb{I}(\mathrm{ENS}_t\geq\zeta_\alpha)$", r"$\mathbf{x}_t$: $L,P_p,P_w,B$, hour",
     r"window $\mathcal{W}_{t-h}$ ($K\times F$)", r"lead time $h$"])
arrow(11, 22, 11, 18.4)

# Stage 2
box(24.5, 11, 16, 20, "white", "Dilated TCN",
    [r"conv $k{=}3$, $d{=}1$", r"$F\!\rightarrow\!16$, ReLU", r"conv $k{=}3$, $d{=}2$",
     r"$16\!\rightarrow\!n$ (linear)", "causal padding", r"tokens $\mathbf{h}_i\in\mathbb{R}^n$"])
arrow(20.4, 11, 24.3, 17)

# Stage 3
box(45, 24.5, 12.5, 9, "white", "Encoding",
    [r"$\varphi_i=\pi\sigma(\mathbf{h}_i)$", r"$\otimes_m R_y(\varphi_{i,m})$"])
for k, (lab, y) in enumerate([(r"$U_Q$", 19.2), (r"$U_K$", 14.2), (r"$U_V$", 9.2)]):
    box(45.5, y - 2.0, 11.5, 4.0, "white", None, [], ec="#b0582c")
    ax.text(51.25, y, lab + r"$\;\rightarrow\;\langle Z\rangle$", ha="center", va="center", fontsize=6.4)
ax.text(51.25, 5.0, r"RealAmpl., $r{=}1$", ha="center", va="center", fontsize=6.0)
arrow(40.6, 21.5, 44.8, 27.5)
arrow(51.25, 24.3, 51.25, 21.4)
box(61, 13, 13.5, 20.5, "white", "Attention",
    [r"$\omega_{ij}\propto e^{-(q_i-k_j)^2}$", r"mask: $j\leq i$", "", r"$\mathbf{y}_i=\mathbf{h}_i$",
     r"$+\sum_j\omega_{ij}\mathbf{v}_j$"])
arrow(57.2, 19.2, 60.8, 24.0)
arrow(57.2, 14.2, 60.8, 20.0)
arrow(57.2, 9.2, 60.8, 16.0)
ax.text(57.4, 22.2, r"$q_i$", fontsize=6.2); ax.text(57.4, 17.4, r"$k_j$", fontsize=6.2)
ax.text(57.4, 12.4, r"$\mathbf{v}_j$", fontsize=6.2)
# residual
ax.annotate("", xy=(67.75, 33.9), xytext=(32.5, 31.4),
            arrowprops=dict(arrowstyle="-|>", lw=0.7, color="#777", ls="--",
                            connectionstyle="arc3,rad=-0.12", mutation_scale=7))
ax.text(39.5, 33.6, "residual", fontsize=6.0, color="#555", ha="center")

# Stage 4
box(78.5, 22, 19.5, 11.5, "white", "Pooling + ZZ map",
    [r"$\mathbf{z}=\frac{1}{2}(\mathbf{y}_K+\bar{\mathbf{y}})$", r"$\boldsymbol{\phi}=\pi\sigma(\mathbf{z})$",
     r"$U_\Phi(\boldsymbol{\phi})$"])
arrow(74.7, 25, 78.3, 27.5)
box(78.5, 10.4, 19.5, 9.0, "white", "Ansatz + measure",
    [r"$U_R(\boldsymbol{\theta}_R)$, $r{=}2$", r"$\hat{\xi}_t=\langle Z_1\rangle$"])
arrow(88.25, 22, 88.25, 19.2)
box(78.5, 3.0, 19.5, 5.2, "#fff7e0", None, [], ec="#a67c00")
ax.text(88.25, 5.6, r"$\hat{P}_t=\sigma(\kappa\hat{\xi}_t+b)$", ha="center", va="center", fontsize=6.6)
arrow(88.25, 10.2, 88.25, 8.4)

# loss feedback
ax.annotate("", xy=(32.5, 10.8), xytext=(78.3, 4.6),
            arrowprops=dict(arrowstyle="-|>", lw=0.7, color="#a67c00", ls="--",
                            connectionstyle="arc3,rad=-0.10", mutation_scale=7))
ax.text(60, 2.4, r"risk-aware loss $\mathcal{L}(w_t)$: end-to-end gradients",
        fontsize=6.0, color="#7a5b00", ha="center")

fig.savefig("figs/fig_framework.png", dpi=300, bbox_inches="tight")
print("saved")
