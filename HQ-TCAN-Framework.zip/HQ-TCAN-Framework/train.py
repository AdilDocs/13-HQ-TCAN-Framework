"""Data windows, risk-aware loss, training protocol and evaluation (autograd/NumPy)."""
import time
import numpy as np
import pandas as pd
import autograd.numpy as anp
from autograd import value_and_grad
from autograd.misc import flatten
from sklearn.metrics import average_precision_score, roc_auc_score, brier_score_loss

from models import build_model, n_params

FEATS = ["L", "P_p", "P_w", "B", "hsin", "hcos"]
SPLIT = {"train": (2015, 2017), "val": (2018, 2018), "test": (2019, 2019)}
CMAX = 3.0


def prepare(h=6, pct=90, K=24, sim_path="sim.pkl"):
    sim = pd.read_pickle(sim_path)
    hr = sim.index.hour.values
    sim = sim.assign(hsin=np.sin(2 * np.pi * hr / 24), hcos=np.cos(2 * np.pi * hr / 24))
    years = sim.index.year.values
    trm = (years >= 2015) & (years <= 2017)
    X = sim[FEATS].values.astype(np.float32)
    lo, hi = X[trm].min(0), X[trm].max(0)                     # scaler fitted on TRAIN only
    X = (X - lo) / (hi - lo + 1e-9)
    ens = sim.ENS.values.astype(np.float32)
    zeta = float(np.percentile(ens[trm], pct))                # tail threshold from TRAIN only
    y = (ens >= zeta).astype(np.float32)
    t_idx = np.arange(K + h - 1, len(sim))                    # target t; window ends at t-h
    W = np.stack([X[t - h - K + 1: t - h + 1] for t in t_idx])
    out = {}
    for name, (a, b) in SPLIT.items():
        m = (years[t_idx] >= a) & (years[t_idx] <= b)
        ti = t_idx[m]
        out[name] = dict(X=W[m], y=y[ti], ens=ens[ti], persist=ens[ti - h], t=sim.index[ti])
    out.update(zeta=zeta, h=h, K=K, pct=pct)
    return out


def risk_weights(y, ens, zeta, lam, pos_w):
    """w_t = pi_+ (1 + lam * min(ENS_t / zeta, c_max)) if S_t = 1, else 1."""
    sev = np.minimum(ens / zeta, CMAX)
    return np.where(y > 0, pos_w * (1 + lam * sev), 1.0)


def risk_loss(logit, y, ens, zeta, lam, pos_w):
    w = risk_weights(y, ens, zeta, lam, pos_w)
    bce = anp.logaddexp(0.0, logit) - y * logit           # BCE-with-logits, numerically stable
    return anp.sum(w * bce) / np.sum(w)


def best_threshold(score, y):
    """tau maximising G-Mean on the VALIDATION set."""
    cands = np.unique(np.quantile(score, np.linspace(0, 1, 401)))
    best, bg = cands[0], -1.0
    for tau in cands:
        p = score >= tau
        g = np.sqrt(p[y == 1].mean() * (~p[y == 0]).mean())
        if g > bg:
            best, bg = tau, g
    return float(best)


def metrics(score, y, tau, n_theta=None, prob=None):
    y = y.astype(int)
    p = score >= tau
    tcr, spe = p[y == 1].mean(), (~p[y == 0]).mean()
    out = dict(TCR=tcr, SPE=spe, GMean=np.sqrt(tcr * spe), FSS=int(((~p) & (y == 1)).sum()),
               FA=int((p & (y == 0)).sum()), PR_AUC=average_precision_score(y, score),
               ROC_AUC=roc_auc_score(y, score), n_pos=int(y.sum()), n=len(y))
    if prob is not None:
        out["Brier"] = brier_score_loss(y, prob)
    if n_theta:
        out["N_theta"], out["PER"] = n_theta, 100 * tcr / n_theta
    return {k: float(v) for k, v in out.items()}


def make_predict(apply, bs=1024):
    def predict(params, X):
        return np.concatenate([np.asarray(apply(params, X[i:i + bs])) for i in range(0, len(X), bs)])
    return predict


def train_nn(name, D, lam=3.0, seed=0, epochs=40, patience=8, lr=3e-3, bs=128, verbose=False):
    init, apply = build_model(name)
    tr, va = D["train"], D["val"]
    rng = np.random.default_rng(seed)
    params = init(rng, tr["X"].shape[-1], D["K"])
    flat, unflat = flatten(params)
    pos_w = float((tr["y"] == 0).sum() / (tr["y"] == 1).sum())
    zeta = D["zeta"]
    m1, m2, it = np.zeros_like(flat), np.zeros_like(flat), 0
    b1, b2, wd = 0.9, 0.999, 1e-4

    def step(flat, x, y, e):
        # Adam with L2 weight decay and global-norm gradient clipping (max norm 1.0)
        nonlocal m1, m2, it
        loss, g = value_and_grad(lambda f: risk_loss(apply(unflat(f), x), y, e, zeta, lam, pos_w))(flat)
        gn = np.linalg.norm(g)
        if gn > 1.0:
            g = g / gn
        g = g + wd * flat
        it += 1
        m1 = b1 * m1 + (1 - b1) * g
        m2 = b2 * m2 + (1 - b2) * g * g
        mh, vh = m1 / (1 - b1 ** it), m2 / (1 - b2 ** it)
        return flat - lr * mh / (np.sqrt(vh) + 1e-8), loss

    predict = make_predict(apply)
    n = len(tr["y"])
    hist = {k: [] for k in ["train_loss", "val_loss", "val_prauc", "val_tcr", "val_spe", "val_gmean", "sec"]}
    best, best_p, wait = -1.0, params, 0
    params = unflat(flat)
    for ep in range(epochs):
        t0 = time.time()
        perm = rng.permutation(n)
        tot = 0.0; nb = 0
        for i in range(0, n - bs + 1, bs):
            idx = perm[i:i + bs]
            flat, loss = step(flat, tr["X"][idx], tr["y"][idx], tr["ens"][idx])
            tot += float(loss); nb += 1
        params = unflat(flat)
        s = predict(params, va["X"])
        vl = float(risk_loss(s, va["y"], va["ens"], zeta, lam, pos_w))
        m = metrics(s, va["y"], best_threshold(s, va["y"]))
        for k, v in [("train_loss", tot / nb), ("val_loss", vl), ("val_prauc", m["PR_AUC"]),
                     ("val_tcr", m["TCR"]), ("val_spe", m["SPE"]), ("val_gmean", m["GMean"]),
                     ("sec", time.time() - t0)]:
            hist[k].append(v)
        if verbose:
            print(f"{name} ep{ep+1} loss {tot/nb:.4f} val {vl:.4f} AP {m['PR_AUC']:.3f} "
                  f"G {m['GMean']:.3f} ({time.time()-t0:.1f}s)", flush=True)
        if m["PR_AUC"] > best + 1e-4:
            best, best_p, wait = m["PR_AUC"], params, 0
            hist["best_epoch"] = ep + 1
        else:
            wait += 1
            if wait >= patience:
                break
    return best_p, apply, hist


def evaluate_nn(params, apply, D):
    predict = make_predict(apply)
    sv = predict(params, D["val"]["X"])
    tau = best_threshold(sv, D["val"]["y"])
    st = predict(params, D["test"]["X"])
    return metrics(st, D["test"]["y"], tau, n_params(params), 1 / (1 + np.exp(-st))), st, tau


def run_classic(kind, D, lam=3.0, seed=0):
    """Persistence, logistic regression and LightGBM (same split and tau rule)."""
    yv, yt = D["val"]["y"], D["test"]["y"]
    if kind == "Persistence":
        sv, st = D["val"]["persist"], D["test"]["persist"]
        tau = best_threshold(sv, yv)
        return metrics(st, yt, tau), st, tau
    tr = D["train"]
    Xtr, Xv, Xt = (d["X"].reshape(len(d["X"]), -1) for d in (tr, D["val"], D["test"]))
    pos_w = float((tr["y"] == 0).sum() / (tr["y"] == 1).sum())
    w = np.asarray(risk_weights(tr["y"], tr["ens"], D["zeta"], lam, pos_w))
    if kind == "Logistic regression":
        from sklearn.linear_model import LogisticRegression
        m = LogisticRegression(max_iter=3000).fit(Xtr, tr["y"], sample_weight=w)
        sv, st, nt = m.decision_function(Xv), m.decision_function(Xt), Xtr.shape[1] + 1
    else:
        import lightgbm as lgb
        m = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.05, num_leaves=31, subsample=0.8,
                               subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1)
        m.fit(Xtr, tr["y"], sample_weight=w)
        sv, st, nt = m.predict_proba(Xv)[:, 1], m.predict_proba(Xt)[:, 1], None
    tau = best_threshold(sv, yv)
    return metrics(st, yt, tau, nt), st, tau


# ======================= tuning-round utilities (v2) =======================

def threshold_at_spe(score, y, spe_min=0.90):
    """Lowest threshold whose VALIDATION specificity is >= spe_min (fixed false-alarm budget)."""
    neg = np.sort(score[y == 0])
    return float(neg[int(np.ceil(spe_min * len(neg))) - 1]) + 1e-9


def full_eval(sv, st, D, n_theta=None, logits=True):
    yv, yt = D["val"]["y"], D["test"]["y"]
    tau = best_threshold(sv, yv)
    prob = 1 / (1 + np.exp(-st)) if logits else None
    m = metrics(st, yt, tau, n_theta, prob)
    tau90 = threshold_at_spe(sv, yv, 0.90)
    m90 = metrics(st, yt, tau90)
    m.update(TCR_at_SPE90=m90["TCR"], SPE_at_SPE90=m90["SPE"], FSS_at_SPE90=m90["FSS"])
    mv = metrics(sv, yv, tau)
    m.update(val_PR_AUC=mv["PR_AUC"], val_GMean=mv["GMean"])
    return m, tau


def train_cfg(cfg, D, lam=1.0, seed=0, epochs=40, patience=8, lr=3e-3, bs=128, plateau=3):
    """As train_nn, plus learning-rate halving after `plateau` epochs without validation gain."""
    from models import build_from_config
    init, apply = build_from_config(cfg)
    tr, va = D["train"], D["val"]
    rng = np.random.default_rng(seed)
    params = init(rng, tr["X"].shape[-1], D["K"])
    flat, unflat = flatten(params)
    pos_w = float((tr["y"] == 0).sum() / (tr["y"] == 1).sum())
    zeta = D["zeta"]
    m1, m2, it = np.zeros_like(flat), np.zeros_like(flat), 0
    b1, b2, wd = 0.9, 0.999, 1e-4
    lr_now = lr
    grad_fn = value_and_grad(lambda f, x, y, e: risk_loss(apply(unflat(f), x), y, e, zeta, lam, pos_w))
    predict = make_predict(apply)
    n = len(tr["y"])
    hist = {k: [] for k in ["train_loss", "val_loss", "val_prauc", "val_tcr", "val_spe", "val_gmean", "lr", "sec"]}
    best, best_flat, wait, since_imp = -1.0, flat, 0, 0
    for ep in range(epochs):
        t0 = time.time()
        perm = rng.permutation(n)
        tot = 0.0; nb = 0
        for i in range(0, n - bs + 1, bs):
            idx = perm[i:i + bs]
            loss, g = grad_fn(flat, tr["X"][idx], tr["y"][idx], tr["ens"][idx])
            gn = np.linalg.norm(g)
            if gn > 1.0:
                g = g / gn
            g = g + wd * flat
            it += 1
            m1 = b1 * m1 + (1 - b1) * g
            m2 = b2 * m2 + (1 - b2) * g * g
            flat = flat - lr_now * (m1 / (1 - b1 ** it)) / (np.sqrt(m2 / (1 - b2 ** it)) + 1e-8)
            tot += float(loss); nb += 1
        s = predict(unflat(flat), va["X"])
        vl = float(risk_loss(s, va["y"], va["ens"], zeta, lam, pos_w))
        m = metrics(s, va["y"], best_threshold(s, va["y"]))
        for k, v in [("train_loss", tot / nb), ("val_loss", vl), ("val_prauc", m["PR_AUC"]), ("val_tcr", m["TCR"]),
                     ("val_spe", m["SPE"]), ("val_gmean", m["GMean"]), ("lr", lr_now), ("sec", time.time() - t0)]:
            hist[k].append(v)
        if m["PR_AUC"] > best + 1e-4:
            best, best_flat, wait, since_imp = m["PR_AUC"], flat, 0, 0
            hist["best_epoch"] = ep + 1
        else:
            wait += 1; since_imp += 1
            if since_imp >= plateau:
                lr_now *= 0.5; since_imp = 0
            if wait >= patience:
                break
    return unflat(best_flat), apply, hist
