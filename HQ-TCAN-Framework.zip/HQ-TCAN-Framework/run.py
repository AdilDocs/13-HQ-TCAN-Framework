"""Experiment runner. Each run is cached in results/<key>.json so experiments are resumable.

usage: python run.py <experiment>   (main | ablation | pct | lam | horizon)
"""
import json, os, sys, time
import numpy as np
import pickle
from train import prepare, train_nn, evaluate_nn, run_classic

os.makedirs("results", exist_ok=True)
NN_MAIN = ["HQ-TCAN (proposed)", "TCN + classical attention", "LSTM [6]", "Transformer [9]",
           "VQC [12]", "HQTCN [14]", "QSANN [24]"]
CLASSIC = ["Persistence", "Logistic regression", "LightGBM"]
ABL = ["w/o quantum attention", "classical attention + VQC", "w/o dilation", "classical readout"]
SEEDS = [0, 1, 2]
_cache = {}


def data(h, pct):
    if (h, pct) not in _cache:
        _cache[(h, pct)] = prepare(h=h, pct=pct)
    return _cache[(h, pct)]


def run(model, h=6, pct=90, lam=3.0, seed=0, tag=""):
    key = f"{tag}{model}|h{h}|p{pct}|l{lam}|s{seed}".replace(" ", "_").replace("/", "-")
    path = f"results/{key}.json"
    if os.path.exists(path):
        return json.load(open(path))
    D = data(h, pct)
    t0 = time.time()
    if model in CLASSIC:
        m, score, tau = run_classic(model, D, lam, seed)
        hist = None
    else:
        params, apply, hist = train_nn(model, D, lam=lam, seed=seed)
        m, score, tau = evaluate_nn(params, apply, D)
        if model == "HQ-TCAN (proposed)" and seed == 0 and tag == "":
            pickle.dump(params, open(f"results/hqtcan_h{h}_p{pct}_l{lam}.pkl", "wb"))
            np.save(f"results/scores_h{h}_p{pct}_l{lam}.npy", score)
    m = {k: (float(v) if isinstance(v, (np.floating, np.integer, float, int)) else v) for k, v in m.items()}
    rec = dict(model=model, h=h, pct=pct, lam=lam, seed=seed, tau=float(tau), zeta=D["zeta"],
               metrics=m, hist=hist, sec=time.time() - t0)
    json.dump(rec, open(path, "w"))
    print(f"{model:28s} h{h} p{pct} l{lam} s{seed}  G {m['GMean']:.3f} TCR {m['TCR']:.3f} "
          f"SPE {m['SPE']:.3f} AP {m['PR_AUC']:.3f} ({time.time()-t0:.0f}s)", flush=True)
    return rec


if __name__ == "__main__":
    exp = sys.argv[1]
    if exp == "main":
        for mdl in CLASSIC:
            run(mdl, seed=0)
        for s in SEEDS:
            for mdl in NN_MAIN:
                run(mdl, seed=s)
    elif exp == "ablation":
        for s in SEEDS:
            for mdl in ABL:
                run(mdl, seed=s)
            run("HQ-TCAN (proposed)", lam=0.0, seed=s)
    elif exp == "reup":
        for s in SEEDS:
            run("HQ-TCAN-RU", seed=s)
    elif exp == "pct":
        for p in [85, 95, 97.5, 99]:
            for mdl in ["Persistence", "LightGBM"]:
                run(mdl, pct=p)
            for s in SEEDS[:2]:
                for mdl in ["HQ-TCAN (proposed)", "TCN + classical attention"]:
                    run(mdl, pct=p, seed=s)
    elif exp == "lam":
        for lam in [1.0, 5.0]:
            for s in SEEDS[:2]:
                run("HQ-TCAN (proposed)", lam=lam, seed=s)
    elif exp == "horizon":
        for h in [1, 3, 12, 24]:
            for mdl in ["Persistence", "LightGBM"]:
                run(mdl, h=h)
            for s in SEEDS[:2]:
                for mdl in ["HQ-TCAN (proposed)", "TCN + classical attention"]:
                    run(mdl, h=h, seed=s)
