"""Generate LaTeX table snippets straight from results/*.json (no hand-typed numbers)."""
import numpy as np
import analyze as A

R = A.R


def sel(m, h=6, pct=90, lam=3.0):
    return R[(R.model == m) & (R.h == h) & (R.pct == pct) & (R.lam == lam)]


def pm(d, k, f="{:.3f}", sd=True):
    if d.empty:
        return "--"
    if len(d) > 1 and sd:
        return (f + "$\\pm$" + f).format(d[k].mean(), d[k].std(ddof=1))
    return f.format(d[k].mean())


def abl_row(name, d):
    return (f"{name} & {pm(d,'TCR')} & {pm(d,'GMean')} & "
            f"{pm(d,'FSS','{:.0f}')} & {pm(d,'PR_AUC')} \\\\")


out = []
out.append("% --- ablation rows")
out.append(abl_row("Re-uploading readout \\cite{ref17}", sel("HQ-TCAN-RU")))
out.append(abl_row("$\\lambda=0$ (no severity weight)", sel("HQ-TCAN (proposed)", lam=0.0)))

MODELS = [("HQ-TCAN", "HQ-TCAN (proposed)"), ("Classical twin", "TCN + classical attention"),
          ("LightGBM", "LightGBM"), ("Persistence", "Persistence")]
for var, vals, lab in [("pct", [85, 90, 95, 97.5, 99], "alpha"), ("h", [1, 3, 6, 12, 24], "h")]:
    out.append(f"% --- sensitivity over {var}")
    for v in vals:
        q = {"h": 6, "pct": 90, "lam": 3.0}; q[var] = v
        cells = []
        for _, m in MODELS:
            d = sel(m, **q)
            cells.append(f"{pm(d,'GMean',sd=False)} / {pm(d,'PR_AUC','{:.2f}',sd=False)}")
        n_pos = int(sel("Persistence", **q).n_pos.mean()) if not sel("Persistence", **q).empty else -1
        zeta = sel("Persistence", **q).zeta.mean()
        out.append(f"{v} & {zeta:,.0f} & {n_pos} & " + " & ".join(cells) + " \\\\")

out.append("% --- lambda")
for lam in [0.0, 1.0, 3.0, 5.0]:
    d = sel("HQ-TCAN (proposed)", lam=lam)
    vap = np.mean([max(h["val_prauc"]) for h in d["hist"]]) if len(d) else np.nan
    out.append(f"{lam:g} & {len(d)} & {vap:.3f} & {pm(d,'TCR')} & {pm(d,'SPE')} & {pm(d,'GMean')} & "
               f"{pm(d,'FSS','{:.0f}')} & {pm(d,'PR_AUC')} & {pm(d,'Brier')} \\\\")

open("figs/table_snippets.tex", "w").write("\n".join(out) + "\n")
print("\n".join(out))
